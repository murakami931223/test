package test01;

public class cytech01 {

	public static void main(String[] args) {
		// TODO 自動生成されたメソッド・スタブ
		int num = 100;
		String text = "あいうえお";
		boolean flag = true;
		
		System.out.println(num);
		System.out.println(text);
		System.out.println(flag);

	}

}
