package test02;

public class cytech02 {

	public static void main(String[] args) {
		
		int number1 = 10;
		int number2 = 50;
		
		System.out.println("10+50="+(number1+number2));
		System.out.println("10-50="+(number1-number2));
		System.out.println("10*50="+(number1*number2));
		System.out.println("10÷50="+(number1/number2));
		System.out.println("10÷50の余り="+(number1%number2));

	}

}
