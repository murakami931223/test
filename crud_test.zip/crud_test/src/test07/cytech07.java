package test07;

public class cytech07 {

	public static void main(String[] args) {
		for(char c = 'あ' ; c <= 'ん'; c++) {
			if(c == 'て') {
				System.out.println(c);
			}
		}

	}

}
